<?php 
require_once('../../config.php');
if(isset($_GET['id']) && $_GET['id'] > 0){
    $qry = $conn->query("SELECT * from `appointments` where id = '{$_GET['id']}' ");
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=$v;
        }
    }
    $qry2 = $conn->query("SELECT * FROM `patient_meta` where patient_id = '{$patient_id}' ");
    foreach($qry2->fetch_all(MYSQLI_ASSOC) as $row){
        $patient[$row['meta_field']] = $row['meta_value'];
    }
}
?>
<style>
#uni_modal .modal-content>.modal-footer{
    display:none;
}
#uni_modal .modal-body{
    padding-top:0 !important;
}
</style>
<div class="container-fluid">
    <form id="appointment_form" class="py-2">
    <div class="row" id="appointment">
        <div class="col-6" id="frm-field">
            <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
            <input type="hidden" name="patient_id" value="<?php echo isset($patient_id) ? $patient_id : '' ?>">
                <div class="form-group">
                    <label for="name" class="control-label">Fullname</label>
                    <input type="text" class="form-control" name="name" value="<?php echo isset($patient['name']) ? $patient['name'] : '' ?>" required>
                </div>
                <div class="form-group">
                    <label for="age" class="control-label">Age</label>
                    <input type="number" class="form-control" name="age" value="<?php echo isset($patient['age']) ? $patient['age'] : '' ?>"  required>
                </div>
                <div class="form-group">
                    <label for="contact" class="control-label">Contact</label>
                    <input type="text" class="form-control" name="contact" value="<?php echo isset($patient['contact']) ? $patient['contact'] : '' ?>"  required>
                </div>
                <div class="form-group">
                    <label for="gender" class="control-label">Gender</label>
                    <select type="text" class="custom-select" name="gender" required>
                    <option <?php echo isset($patient['gender']) && $patient['gender'] == "Male" ? "selected": "" ?>>Male</option>
                    <option <?php echo isset($patient['gender']) && $patient['gender'] == "Female" ? "selected": "" ?>>Female</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="dob" class="control-label">Date of Birth</label>
                    <input type="date" class="form-control" name="dob" value="<?php echo isset($patient['dob']) ? $patient['dob'] : '' ?>"  required>
                </div>
        </div>
        <div class="col-6">
                
                <div class="form-group">
                    <label for="address" class="control-label">Address</label>
                    <textarea class="form-control" name="address" rows="3" required><?php echo isset($patient['address']) ? $patient['address'] : '' ?></textarea>
                </div>
                <div id="service-therapist-container">
                    <!-- Service and Therapist rows will be added here by JavaScript -->
                    <?php
                    // Assume $patient['services'] and $patient['therapist'] are comma-separated strings
                    $services_arr = isset($patient['services']) && !empty($patient['services']) ? explode(',', $patient['services']) : [''];
                    $therapist_arr = isset($patient['therapist']) && !empty($patient['therapist']) ? explode(',', $patient['therapist']) : [''];

                    // Ensure there's at least one empty pair if no data
                    if (empty($services_arr) && empty($therapist_arr)) {
                        $services_arr = [''];
                        $therapist_arr = [''];
                    } else {
                         // Ensure both arrays have the same size by padding with empty strings if needed
                        $max_count = max(count($services_arr), count($therapist_arr));
                        while(count($services_arr) < $max_count) $services_arr[] = '';
                        while(count($therapist_arr) < $max_count) $therapist_arr[] = '';
                    }


                    for ($i = 0; $i < count($services_arr); $i++) {
                        $current_service = trim($services_arr[$i]);
                        $current_therapist = trim($therapist_arr[$i]);
                    ?>
                        <div class="row service-therapist-row mb-2">
                            <div class="col-md-5">
                                <div class="form-group">
                                    <?php if ($i == 0): // Only show label for the first row ?>
                                    <label for="services" class="control-label">Services to be availed </label>
                                    <?php endif; ?>
                                    <select class="custom-select service-select" name="services[]" required>
                                        <option value="">Select Service</option>
                                        <option value="Triple Bogey Strokes" <?php echo $current_service == "Triple Bogey Strokes" ? "selected" : ""; ?>>Triple Bogey Strokes (1hr & 15 mins ₱599.00)</option>
                                        <option value="Hole-in-One Strokes" <?php echo $current_service == "Hole-in-One Strokes" ? "selected" : ""; ?>>Hole-in-One Strokes (50 mins ₱399.00)</option>
                                        <option value="Par Strokes" <?php echo $current_service == "Par Strokes" ? "selected" : ""; ?>>Par Strokes (50 mins ₱350.00)</option>
                                        <option value="Eagle Strokes" <?php echo $current_service == "Eagle Strokes" ? "selected" : ""; ?>>Eagle Strokes (50 mins ₱599.00)</option>
                                        <option value="Condor Stroke" <?php echo $current_service == "Condor Stroke" ? "selected" : ""; ?>>Condor Stroke (2 hours ₱999.00)</option>
                                        <option value="Body Scrub" <?php echo $current_service == "Body Scrub" ? "selected" : ""; ?>>Body Scrub (30mins ₱ 350.00)</option>
                                        <option value="Body Scrub w/ full body massage" <?php echo $current_service == "Body Scrub w/ full body massage" ? "selected" : ""; ?>>Body Scrub w/ full body massage (₱799.00 1 hr & 20 mins)</option>
                                        <option value="Hot Compress or Ear Candle w/ full body massage" <?php echo $current_service == "Hot Compress or Ear Candle w/ full body massage" ? "selected" : ""; ?>>Hot Compress or Ear Candle w/ full body massage (₱449 1 hr & 10 mins)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-5">
                <div class="form-group">
                                    <?php if ($i == 0): // Only show label for the first row ?>
                                    <label for="therapist" class="control-label">Select Therapist</label>
                                    <?php endif; ?>
                                    <select class="custom-select therapist-select" name="therapist[]" required>
                                        <option value="">Select Therapist</option>
                                        <option value="Valerie" <?php echo $current_therapist == "Valerie" ? "selected" : ""; ?>>Valerie</option>
                                        <option value="Vanessa" <?php echo $current_therapist == "Vanessa" ? "selected" : ""; ?>>Vanessa</option>
                                        <option value="Satchie" <?php echo $current_therapist == "Satchie" ? "selected" : ""; ?>>Satchie</option>
                                        <option value="Bella" <?php echo $current_therapist == "Bella" ? "selected" : ""; ?>>Bella</option>
                                        <option value="Kimmy" <?php echo $current_therapist == "Kimmy" ? "selected" : ""; ?>>Kimmy</option>
                                        <option value="Xander" <?php echo $current_therapist == "Xander" ? "selected" : ""; ?>>Xander</option>
                                        <option value="ian" <?php echo $current_therapist == "ian" ? "selected" : ""; ?>>ian</option>
                                        <option value="MC" <?php echo $current_therapist == "MC" ? "selected" : ""; ?>>MC</option>
    </select>
</div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <?php if ($i == 0): ?>
                                    <label class="control-label">&nbsp;</label>
                                    <?php endif; ?>
                                    <div class="d-flex align-items-end h-100">
                                        <button class="btn btn-danger btn-sm remove-row" type="button"><i class="fa fa-times"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <button class="btn btn-success btn-sm mt-2 mb-3" type="button" id="add-service-therapist">+ Add Another Service</button>
                <div class="form-group">
                <label for="ailment" class="control-label">Ailment</label>
                <textarea class="form-control" name="ailment" rows="3" required><?php echo isset($ailment)? $ailment : "" ?></textarea>
            </div>
                
<?php if($_settings->userdata('id') > 0): ?>
            <div class="form-group">
                <label for="status" class="control-label">Status</label>
                <select name="status" id="status" class="custom custom-select">
                    <option value="0"<?php echo isset($status) && $status == "0" ? "selected": "" ?>>Pending</option>
                    <option value="1"<?php echo isset($status) && $status == "1" ? "selected": "" ?>>Confirmed</option>
                    <option value="2"<?php echo isset($status) && $status == "2" ? "selected": "" ?>>Cancelled</option>
                </select>
            </div>
            <?php else: ?>
                <input type="hidden" name="status" value="0">
            <?php endif; ?>

<?php
if (isset($patient['services'])) {
    echo "<p><strong>Selected Service:</strong> " . htmlspecialchars($patient['services']) . "</p>";
} else {

}
?>

            <div class="form-group">
                <label for="date_sched" class="control-label">Appointment</label>
                <input type="datetime-local" class="form-control" name="date_sched" value="<?php echo isset($date_sched)? date("Y-m-d\TH:i",strtotime($date_sched)) : "" ?>" required>
            </div>
            <?php if($_settings->userdata('id') > 0): ?>
            <div class="form-group">
                
                </select>
            </div>
            <?php else: ?>
                <input type="hidden" name="status" value="0">
            <?php endif; ?>
        </div>
        <div class="form-group d-flex justify-content-end w-100 form-group">
            <button class="btn-primary btn">Submit Appointment</button>
            <button class="btn-light btn ml-2" type="button" data-dismiss="modal">Cancel</button>
        </div>
        </form>
    </div>
</div>
<script>
$(function(){
    $('#appointment_form').submit(function(e){
        e.preventDefault();
        var _this = $(this)
        $('.err-msg').remove();

        // Debug log
        console.log("Form submitted");

        // Get all selected therapists and their times
        var therapists = [];
        var date_sched = $('input[name="date_sched"]').val();
        
        $('.therapist-select').each(function() {
            var therapist = $(this).val();
            if(therapist) {
                therapists.push(therapist);
            }
        });

        // Debug log
        console.log("Therapists:", therapists);
        console.log("Date scheduled:", date_sched);

        // Check for therapist conflicts
        $.ajax({
            url: _base_url_ + "classes/Master.php?f=check_therapist_conflict",
            data: {
                therapists: therapists,
                date_sched: date_sched,
                appointment_id: $('input[name="id"]').val()
            },
            dataType: 'json',
            error: err => {
                console.log("Conflict check error:", err);
                alert_toast("Error checking therapist availability. Please try again.", 'error');
            },
            success: function(resp) {
                console.log("Conflict check response:", resp);
                
                if(resp.status == 'conflict') {
                    // Create a more visible error popup
                    var el = $('<div>')
                        .addClass("alert alert-danger err-msg")
                        .html('<i class="fa fa-exclamation-triangle"></i> <strong>Error:</strong> ' + resp.msg)
                        .css({
                            'position': 'fixed',
                            'top': '20px',
                            'left': '50%',
                            'transform': 'translateX(-50%)',
                            'z-index': '9999',
                            'padding': '15px 20px',
                            'border-radius': '5px',
                            'box-shadow': '0 2px 5px rgba(0,0,0,0.2)',
                            'min-width': '300px',
                            'text-align': 'center'
                        });
                    
                    // Add close button
                    var closeBtn = $('<button>')
                        .addClass('close')
                        .html('&times;')
                        .css({
                            'position': 'absolute',
                            'right': '10px',
                            'top': '5px',
                            'background': 'none',
                            'border': 'none',
                            'font-size': '20px',
                            'cursor': 'pointer'
                        })
                        .on('click', function() {
                            el.fadeOut(300, function() {
                                $(this).remove();
                            });
                        });
                    
                    el.append(closeBtn);
                    $('body').append(el);
                    
                    // Auto-remove after 5 seconds
                    setTimeout(function() {
                        el.fadeOut(300, function() {
                            $(this).remove();
                        });
                    }, 5000);
                    
                    return;
                }
                
                // If no conflicts, proceed with saving
                var formData = new FormData(_this[0]);
                console.log("Saving appointment with data:", Object.fromEntries(formData));
                
                $.ajax({
                    url: _base_url_ + "classes/Master.php?f=save_appointment",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    method: 'POST',
                    type: 'POST',
                    dataType: 'json',
                    error: err => {
                        console.log("Save error:", err);
                        alert_toast("Error saving appointment. Please try again.", 'error');
                    },
                    success: function(resp) {
                        console.log("Save response:", resp);
                        
                        if(typeof resp == 'object' && resp.status == 'success') {
                            alert_toast("Appointment saved successfully!", 'success');
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                        } else if(resp.status == 'failed' && !!resp.msg) {
                            var el = $('<div>')
                                .addClass("alert alert-danger err-msg")
                                .text(resp.msg);
                            _this.prepend(el);
                            el.show('slow');
                            $("html, body").animate({ scrollTop: $('#uni_modal').offset().top }, "fast");
                        } else {
                            alert_toast("An error occurred while saving the appointment.", 'error');
                            console.log(resp);
                        }
                    }
                });
            }
        });
    });

    // Add console logs for debugging
    console.log("Form submission handler attached");
    
    // Test if jQuery is working
    $(document).ready(function() {
        console.log("Document ready");
        console.log("Form exists:", $('#appointment_form').length > 0);
        console.log("Base URL:", _base_url_);
    });

    $('#uni_modal').on('hidden.bs.modal', function (e) {
        if($('#appointment_form').length <= 0)
            location.reload()
    })
})
</script>
<script>
$(document).ready(function() {
    // Function to check service limit
    function checkServiceLimit() {
        var serviceCount = $('.service-therapist-row').length;
        if (serviceCount >= 3) {
            // Show notification
            alert('Maximum of 3 services allowed per appointment.');
            return false;
        }
        return true;
    }

    // Add new row
    $('#add-service-therapist').click(function() {
        if (!checkServiceLimit()) return;
        
        var newRow = $('.service-therapist-row:first').clone();
        newRow.find('select').val('');
        $('#service-therapist-container').append(newRow);
    });

    // Remove row
    $(document).on('click', '.remove-row', function() {
        if ($('.service-therapist-row').length > 1) {
            $(this).closest('.service-therapist-row').remove();
        } else {
            $(this).closest('.service-therapist-row').find('select').val('');
        }
    });

    // Form submission validation
    $('form').submit(function(e) {
        var serviceCount = $('.service-therapist-row').length;
        if (serviceCount > 3) {
            e.preventDefault();
            alert('Maximum of 3 services allowed per appointment.');
            return false;
        }
    });
});
</script>


