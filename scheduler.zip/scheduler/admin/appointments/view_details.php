<?php
require_once('../../config.php');

// Initialize $patient array
$patient = [];

if(isset($_GET['id']) && $_GET['id'] > 0){
    $qry = $conn->query("SELECT a.*, p.name FROM `appointments` a inner join `patient_list` p on a.patient_id = p.id where a.id = '{$_GET['id']}' ");
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=$v;
        }

        // Populate $patient array with core details from patient_list
        $patient['name'] = $name;
    }

    // Fetch patient_meta data for other fields
    $qry2 = $conn->query("SELECT * FROM `patient_meta` where patient_id = '{$patient_id}' ");
    $patient_meta = [];
    while($row = $qry2->fetch_assoc()){
        $patient_meta[$row['meta_field']][] = $row['meta_value'];
    }
  }
?>
<style>
#uni_modal .modal-content>.modal-footer{
    display:none;
}
#uni_modal .modal-body{
    padding-bottom:0 !important;
}
</style>
<div class="container-fluid">
    <p><b>Appointment Schedule:</b> <?php echo isset($date_sched) ? date("F d, Y",strtotime($date_sched)) : 'N/A'  ?></p>
    <p><b>Start Time:</b> <?php echo isset($date_sched) ? date("h:i A",strtotime($date_sched)) : 'N/A'  ?></p>
    <p><b>End Time:</b> 
        <?php 
        if(isset($date_sched) && isset($patient_meta['services'])) {
            $start_time = strtotime($date_sched);
            $total_duration = 0;
            
            foreach($patient_meta['services'] as $service) {
                switch($service) {
                    case "Triple Bogey Strokes":
                        $total_duration += 75; // 1hr & 15 mins
                        break;
                    case "Hole-in-One Strokes":
                        $total_duration += 50;
                        break;
                    case "Par Strokes":
                        $total_duration += 50;
                        break;
                    case "Eagle Strokes":
                        $total_duration += 50;
                        break;
                    case "Condor Stroke":
                        $total_duration += 120; // 2 hours
                        break;
                    case "Body Scrub":
                        $total_duration += 30;
                        break;
                    case "Body Scrub w/ full body massage":
                        $total_duration += 80; // 1 hr & 20 mins
                        break;
                    case "Hot Compress or Ear Candle w/ full body massage":
                        $total_duration += 70; // 1 hr & 10 mins
                        break;
                }
            }
            
            $end_time = strtotime("+{$total_duration} minutes", $start_time);
            echo date("h:i A", $end_time);
        } else {
            echo 'N/A';
        }
        ?>
    </p>
    <p><b>Patient Name:</b> <?php echo isset($patient['name']) ? $patient['name'] : 'N/A' ?></p>
    <p><b>Gender:</b> <?php echo isset($patient_meta['gender'][0]) ? ucwords($patient_meta['gender'][0]) : 'N/A' ?></p>
    <p><b>Date of Birth:</b> <?php echo isset($patient_meta['dob'][0]) ? date("F d, Y",strtotime($patient_meta['dob'][0])) : 'N/A' ?></p>
    <p><b>Contact #:</b> <?php echo isset($patient_meta['contact'][0]) ? $patient_meta['contact'][0] : 'N/A' ?></p>
    <p><b>Age:</b> <?php echo isset($patient_meta['age'][0]) ? htmlspecialchars($patient_meta['age'][0]) : 'N/A' ?></p>
    <p><b>Address:</b> <?php echo isset($patient_meta['address'][0]) ? $patient_meta['address'][0] : 'N/A' ?></p>
    <p><b>Ailment:</b> <?php echo isset($ailment) ? $ailment : 'N/A' ?></p>
    <p><b>Services:</b>
        <?php if (isset($patient_meta['services']) && !empty($patient_meta['services'])): ?>
            <ul>
                <?php foreach ($patient_meta['services'] as $service): ?>
                    <li>
                        <?php 
                        switch($service) {
                            case "Triple Bogey Strokes":
                                echo "Triple Bogey Strokes (1hr & 15 mins ₱599.00)";
                                break;
                            case "Hole-in-One Strokes":
                                echo "Hole-in-One Strokes (50 mins ₱399.00)";
                                break;
                            case "Par Strokes":
                                echo "Par Strokes (50 mins ₱350.00)";
                                break;
                            case "Eagle Strokes":
                                echo "Eagle Strokes (50 mins ₱599.00)";
                                break;
                            case "Condor Stroke":
                                echo "Condor Stroke (2 hours ₱999.00)";
                                break;
                            case "Body Scrub":
                                echo "Body Scrub (30mins ₱350.00)";
                                break;
                            case "Body Scrub w/ full body massage":
                                echo "Body Scrub w/ full body massage (₱799.00 1 hr & 20 mins)";
                                break;
                            case "Hot Compress or Ear Candle w/ full body massage":
                                echo "Hot Compress or Ear Candle w/ full body massage (₱449 1 hr & 10 mins)";
                                break;
                            default:
                                echo htmlspecialchars($service);
                        }
                        ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            N/A
        <?php endif; ?>
    </p>
    <p><b>Therapists:</b>
        <?php if (isset($patient_meta['therapist']) && !empty($patient_meta['therapist'])): ?>
            <ul>
                <?php foreach ($patient_meta['therapist'] as $therapist): ?>
                    <li><?php echo htmlspecialchars($therapist); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            N/A
        <?php endif; ?>
    </p>
    <p><b>Status:</b>
        <?php 
        switch($status){ 
            case(0): 
                echo '<span class="badge badge-primary">Pending</span>';
            break; 
            case(1): 
            echo '<span class="badge badge-success">Confirmed</span>';
            break; 
            case(2): 
                echo '<span class="badge badge-danger">Cancelled</span>';
            break; 
            default: 
                echo '<span class="badge badge-secondary">NA</span>';
        }
        ?>
    </p>
</div>
<div class="modal-footer border-0">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div>
